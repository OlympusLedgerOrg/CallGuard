// src/ws/liveCall.js
// WebSocket server for real-time owner dashboard features:
//   - Live transcript streaming (caller + Ava turns pushed as they happen)
//   - Owner join / take-over notifications
//   - Mid-call SMS dispatch
//
// The app connects when it sees LIVE CALL on the home screen.
// The server pushes events; the app reacts without polling.

import { WebSocketServer } from "ws";
import { sendMidCallInfo } from "../sms/sms.js";
import db from "../db/client.js";

// callSid → Set<WebSocket>  (multiple owners could watch the same call)
const callRooms = new Map();

// ── Attach WS server to existing HTTP server ────────────────────
export function attachWebSocketServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws, req) => {
    const url = new URL(req.url, "ws://localhost");
    const callSid = url.searchParams.get("callSid");
    const role = url.searchParams.get("role") || "owner"; // owner | monitor

    if (!callSid) {
      ws.close(1008, "callSid required");
      return;
    }

    // Add to room
    if (!callRooms.has(callSid)) callRooms.set(callSid, new Set());
    callRooms.get(callSid).add(ws);

    console.log(`[WS] ${role} joined call room ${callSid}. Room size: ${callRooms.get(callSid).size}`);

    // Send current state on join
    ws.send(JSON.stringify({
      event: "connected",
      callSid,
      role,
      ts: Date.now(),
    }));

    // ── Incoming messages from owner ──────────────────────────
    ws.on("message", async (raw) => {
      let msg;
      try { msg = JSON.parse(raw); }
      catch { return; }

      switch (msg.event) {
        // Owner wants to listen silently (no action needed server-side for now)
        case "listen_in":
          broadcastToRoom(callSid, { event: "mode_change", mode: "listen", ts: Date.now() }, ws);
          break;

        // Owner is taking over the call — notify Ava to pause
        case "take_over":
          broadcastToRoom(callSid, { event: "mode_change", mode: "owner_live", ts: Date.now() });
          await logCallEvent(callSid, "owner_took_over");
          break;

        // Owner handing back to Ava
        case "hand_back":
          broadcastToRoom(callSid, { event: "mode_change", mode: "ai", ts: Date.now() });
          await logCallEvent(callSid, "handed_back_to_ai");
          break;

        // Owner sending info SMS to caller mid-call
        case "send_sms": {
          const { body, businessId, toNumber } = msg;
          if (!body || !toNumber) break;
          try {
            const call = await db.calls.findFirst({ where: { call_sid: callSid } });
            const business = await db.businesses.findUnique({ where: { id: businessId } });
            if (!business) break;

            await sendMidCallInfo({
              business,
              toNumber,
              body,
              callId: call?.id,
            });

            // Echo the sent message back to all room watchers
            broadcastToRoom(callSid, {
              event:    "sms_sent",
              body,
              to:       toNumber,
              ts:       Date.now(),
            });
          } catch (err) {
            ws.send(JSON.stringify({ event: "error", message: err.message }));
          }
          break;
        }

        // Owner ending the call
        case "end_call":
          broadcastToRoom(callSid, { event: "call_ended", ts: Date.now() });
          break;
      }
    });

    ws.on("close", () => {
      const room = callRooms.get(callSid);
      if (room) {
        room.delete(ws);
        if (room.size === 0) callRooms.delete(callSid);
      }
      console.log(`[WS] Connection closed for call ${callSid}`);
    });

    ws.on("error", (err) => {
      console.error(`[WS] Error on call ${callSid}:`, err.message);
    });
  });

  return wss;
}

// ── Push a transcript line to all room watchers ─────────────────
// Called by the voice route after each Ava turn or STT result
export function pushTranscriptLine(callSid, line) {
  // line: { from: "ava"|"caller", text: string, ts: number }
  broadcastToRoom(callSid, { event: "transcript_line", line });
}

// ── Push call status update ──────────────────────────────────────
export function pushCallStatus(callSid, status) {
  broadcastToRoom(callSid, { event: "call_status", status, ts: Date.now() });
}

// ── Push disposition when Ava determines outcome ─────────────────
export function pushDisposition(callSid, disposition) {
  broadcastToRoom(callSid, { event: "disposition", disposition, ts: Date.now() });
}

// ── Broadcast to all sockets in a room ──────────────────────────
function broadcastToRoom(callSid, payload, exclude = null) {
  const room = callRooms.get(callSid);
  if (!room) return;
  const data = JSON.stringify(payload);
  for (const ws of room) {
    if (ws !== exclude && ws.readyState === 1) {
      ws.send(data);
    }
  }
}

// ── Log call event to DB ─────────────────────────────────────────
async function logCallEvent(callSid, event) {
  try {
    const call = await db.calls.findFirst({ where: { call_sid: callSid } });
    if (!call) return;
    if (event === "owner_took_over") {
      await db.calls.update({
        where: { id: call.id },
        data:  { owner_joined: true },
      });
    }
  } catch (err) {
    console.error("[WS] logCallEvent error:", err.message);
  }
}
