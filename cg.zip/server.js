// src/server.js
// CallGuard — Ava Backend
// Entry point: Express HTTP + WebSocket server

import "dotenv/config";
import http from "http";
import express from "express";
import { attachWebSocketServer } from "./ws/liveCall.js";
import voiceRouter from "./routes/voice.js";
import apiRouter   from "./routes/api.js";
import db from "./db/client.js";

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: false })); // Twilio posts form-encoded
app.use(express.json());

// Basic request logger
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ── Routes ────────────────────────────────────────────────────────
app.use("/voice", voiceRouter); // Twilio webhooks
app.use("/api",   apiRouter);   // Mobile app REST API

// 404
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

// Error handler
app.use((err, _req, res, _next) => {
  console.error("[Server Error]", err);
  res.status(500).json({ error: "Internal server error" });
});

// ── Boot ──────────────────────────────────────────────────────────
const httpServer = http.createServer(app);
attachWebSocketServer(httpServer);

httpServer.listen(PORT, async () => {
  console.log(`
╔═══════════════════════════════════════════════════╗
║   CallGuard · Ava Backend · v1.0                  ║
╠═══════════════════════════════════════════════════╣
║   HTTP  →  http://localhost:${PORT}                  ║
║   WS    →  ws://localhost:${PORT}/ws                 ║
╠═══════════════════════════════════════════════════╣
║   Twilio webhooks:                                ║
║     POST /voice/inbound   ← new call              ║
║     POST /voice/input     ← caller spoke          ║
║     POST /voice/status    ← call lifecycle        ║
╠═══════════════════════════════════════════════════╣
║   Dashboard API:                                  ║
║     GET  /api/stats        ← home screen stats    ║
║     GET  /api/calls        ← call history         ║
║     GET  /api/jobs         ← job requests         ║
║     GET  /api/appointments ← calendar             ║
║     POST /api/calls/:sid/sms ← mid-call SMS       ║
╚═══════════════════════════════════════════════════╝
  `);

  // Test DB connection
  try {
    await db.$connect();
    console.log("✅ Database connected");
  } catch (err) {
    console.error("❌ Database connection failed:", err.message);
    console.error("   Check DATABASE_URL in .env");
  }
});

// Graceful shutdown
process.on("SIGTERM", async () => {
  console.log("Shutting down...");
  await db.$disconnect();
  httpServer.close(() => process.exit(0));
});
