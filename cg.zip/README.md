# CallGuard — Ava Backend

AI voice receptionist for HVAC & mechanic shops. Answers calls, books jobs, sends SMS confirmations — while the owner is working.

---

## Stack

| Layer | Tech |
|---|---|
| Runtime | Node.js 20+ (ESM) |
| HTTP | Express 4 |
| Database | PostgreSQL + Prisma 5 |
| Phone | Twilio Voice + SMS |
| Speech-to-text | Twilio Enhanced STT (built-in, free) |
| Text-to-speech | AWS Polly via Twilio (no extra cost) |
| Realtime | WebSocket (`ws`) |
| Dialogue | Local rule engine — no LLM, zero per-call cost |

---

## Setup

### 1. Install

```bash
npm install
cp .env.example .env
# Fill in .env with your keys
```

### 2. Database

```bash
# Push schema to your PostgreSQL instance
npm run db:push

# Or run migrations
npm run db:migrate
```

### 3. Seed a business

```bash
node -e "
import('./src/db/client.js').then(async ({default:db}) => {
  const biz = await db.businesses.create({
    data: {
      name: 'Apex HVAC & Mechanical',
      owner_email: 'owner@apexhvac.com',
      phone: '+18285550100',
      address: '204 Oak Ave, Boone NC 28607',
      ai_config: {}
    }
  });
  await db.twilio_numbers.create({
    data: { business_id: biz.id, number: process.env.TWILIO_PHONE_NUMBER }
  });
  console.log('Business created:', biz.id);
});
"
```

### 4. Run (dev)

```bash
npm run dev
```

### 5. Expose to Twilio (local dev)

```bash
# Install ngrok: https://ngrok.com
ngrok http 3000

# Copy the https URL → paste into BASE_URL in .env
# e.g. BASE_URL=https://abc123.ngrok.io
```

### 6. Configure Twilio

In your Twilio console, set your phone number's webhooks:
- **Incoming call (Voice):** `POST https://your-url.ngrok.io/voice/inbound`
- **Call status callback:** `POST https://your-url.ngrok.io/voice/status`

---

## How a call flows

```
Caller dials your Twilio number
        ↓
POST /voice/inbound
  → create calls + transcripts in DB
  → Ava greets caller (TwiML Gather)
        ↓
Caller speaks → Twilio STT → POST /voice/input
  → Ava.processInput() classifies intent
  → routes through gate (TRIAGE → LOGISTICS → OFFER → CAPTURE)
  → returns next TwiML
  → pushes transcript line to WebSocket
        ↓
... turns repeat until CONFIRMED / LEAD / CALLBACK / EMERGENCY ...
        ↓
Call ends → POST /voice/status
  → creates job_request in DB
  → if booked: creates appointment + sends customer SMS confirmation
  → if missed/lead: sends owner alert SMS
  → closes session
```

---

## WebSocket (live call dashboard)

Connect from the app when a live call is active:

```js
const ws = new WebSocket(`wss://your-url/ws?callSid=${callSid}&role=owner`);

ws.onmessage = (e) => {
  const msg = JSON.parse(e.data);
  // Events: connected | transcript_line | call_status | disposition | mode_change | sms_sent
};

// Send info SMS to caller mid-call
ws.send(JSON.stringify({
  event: 'send_sms',
  body: 'We are 10 mins away.',
  businessId: 'your-biz-id',
  toNumber: '+18285551234'
}));

// Take over the call
ws.send(JSON.stringify({ event: 'take_over' }));

// Hand back to Ava
ws.send(JSON.stringify({ event: 'hand_back' }));
```

---

## API routes

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Server health check |
| GET | `/api/stats?businessId=` | Home screen stats (calls, AI rate, bookings, avg time) |
| GET | `/api/calls?businessId=` | Call history with transcript summaries |
| GET | `/api/calls/:id/transcript` | Full transcript lines for one call |
| GET | `/api/jobs?businessId=` | Job requests (new, scheduled, lead) |
| GET | `/api/appointments?businessId=` | Upcoming appointments |
| POST | `/api/appointments` | Manual booking from the app |
| POST | `/api/calls/:callSid/sms` | Send mid-call info SMS |
| POST | `/api/jobs/:id/follow-up` | Send follow-up SMS to a lead |

---

## Adding a new business type

1. Add a config object in `config/businesses.js`
2. Set `business_type` on the `businesses` table row
3. Add any new intent patterns in `src/dialogue/ava.js` → `INTENTS`
4. Ava reads the config at call start — no code changes needed per customer

---

## Production checklist

- [ ] Encrypt `access_token` / `refresh_token` in `oauth_tokens` (use `crypto.createCipheriv`)
- [ ] Add JWT auth middleware to `/api/*` routes
- [ ] Validate Twilio webhook signatures (`twilio.validateExpressRequest`)
- [ ] Move sessions from in-memory Map → Redis (for multi-instance deploy)
- [ ] Set `NODE_ENV=production` to disable query logging
- [ ] Add rate limiting (`express-rate-limit`) to `/api` routes
- [ ] Run `npm run db:migrate` (not `db:push`) in production

---

## Cost at zero customers

| Service | Cost |
|---|---|
| Twilio phone number | $1/month |
| Twilio per-minute (inbound) | $0.013/min |
| Twilio SMS | $0.0079/message |
| Railway (DB + server) | $5/month |
| STT (Twilio Enhanced) | included |
| TTS (Polly via Twilio) | included |
| **Total fixed** | **~$6/month** |

Scales with call volume — no flat LLM API bill.
